﻿var s3 = require('s3');
var AWS = require("aws-sdk");

// To publish, supply an argument "production" or "staging."

var config = {};

// Put all args into an object
var args = {};
process.argv.forEach(function (val, index, array) {
    args[val] = true;
});

if (args.staging) {
    config.profile = "comecero-staging";
    config.region = "us-west-2";
    config.bucket = "comecero-staging-admin";
}

if (args.production) {
    config.profile = "comecero-production";
    config.region = "us-east-1";
    config.bucket = "comecero-admin";
}

if (args.staging && args.production) {
    console.log("You can only supply one environment that you want to publish to: staging, production");
    process.exit();
}

if (!config.profile) {
    console.log("You must supply the environment that you want to publish to: staging, production");
    process.exit();
}

console.log("Preparing to publish to: " + config.profile);
console.log("Region: " + config.region);
console.log("Bucket: " + config.bucket);

// Read the credentials file
var credentials = new AWS.SharedIniFileCredentials({ profile: config.profile });
AWS.config.credentials = credentials;

var client = s3.createClient({
    s3Options: {
        credentials: credentials,
        region: config.region
    },
});

var bucket = config.bucket;

var uploads = [];

var createFolderParam = function (folder) {
    var param = {
        localDir: __dirname + "/" + folder,
        s3Params: { Bucket: bucket, Prefix: "website/" + folder + "/" },
        deleteRemoved: true,
    }
    return param;
}

var createFileParam = function (file) {
    var param = {
        localFile: __dirname + "/" + file,
        s3Params: { Bucket: bucket, Key: "website/" + file, }
    }
    return param;
}

if (Object.keys(args).length < 3) {
    console.log("You have not indicated what you would like to publish. Please provide 'website', 'docs' or 'all'.");
}

console.log("Preparing to publish website files");
uploads.push(createFolderParam("app/modals"));
uploads.push(createFolderParam("app/pages"));
uploads.push(createFolderParam("app/templates"));
uploads.push(createFolderParam("dist"));
uploads.push(createFolderParam("dist"));
uploads.push(createFolderParam("fonts"));
uploads.push(createFolderParam("images"));
uploads.push(createFolderParam("launch"));
uploads.push(createFolderParam("login"));
uploads.push(createFolderParam("oauth"));
uploads.push(createFolderParam("oauth-proxy"));
uploads.push(createFolderParam("languages"));
uploads.push(createFileParam("index.html"));
uploads.push(createFileParam("version.html"));
uploads.push(createFileParam("CHANGELOG.md"));

// Loop through folders and upload.
uploads.forEach(function (param) {

    var name;
    if (param.localDir) {
        name = "directory: " + param.localDir;
    } else {
        name = "file: " + param.localFile;
    }

    console.log("Preparing to upload " + name);

    var uploader;
    if (param.localDir) {
        uploader = client.uploadDir(param);
    } else {
        uploader = client.uploadFile(param);
    }

    uploader.on('error', function (err) { console.error("Unable to upload: ", err.stack); });
    uploader.on('end', function () { console.log("Finished uploading " + name); });

});
